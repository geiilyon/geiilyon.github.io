package sensepresso.controller;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;

import sensepresso.model.CoffeeMachine;
import sensepresso.view.CoffeeMachineGUI;

public class Main {

	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				launch();
			}
		});
	}

	protected static void launch() {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		CoffeeMachine coffeeMachine = new CoffeeMachine();

		CoffeeMachineGUI gui = new CoffeeMachineGUI(coffeeMachine);

		coffeeMachine.addObserver(gui);
		
		gui.createAndShowUI();
		
	}

}
