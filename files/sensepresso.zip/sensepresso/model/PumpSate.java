package sensepresso.model;

public enum PumpSate {
	ON,
	OFF

}
