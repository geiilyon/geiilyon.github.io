package sensepresso.model;

public enum LedState {
	OFF,
	ON,
	BLINKING_SLOW,
	BLINKING_FAST

}
