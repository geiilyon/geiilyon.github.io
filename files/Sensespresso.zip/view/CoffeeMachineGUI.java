package view;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Observable;
import java.util.Observer;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import model.CoffeeMachine;
import model.PumpSate;
import eu.hansolo.steelseries.extras.Led;
import eu.hansolo.steelseries.gauges.AbstractRadial;
import eu.hansolo.steelseries.gauges.Linear;
import eu.hansolo.steelseries.gauges.Radial;
import eu.hansolo.steelseries.gauges.Radial1Square;
import eu.hansolo.steelseries.gauges.Radial1Vertical;
import eu.hansolo.steelseries.tools.BackgroundColor;
import eu.hansolo.steelseries.tools.ColorDef;

public class CoffeeMachineGUI implements Observer {
	private static final int SPACER_SIZE = 20;
	private static final int GAUGE_SIZE = 250;
	private static final int LED_SIZE = 40;
	private static final int BLINK_PERIOD_FAST = 2;
	private static final int BLINK_PERIOD_SLOW = 5;
	private Radial temperatureGauge;

	private AbstractRadial pressureGauge;
	private Led heatingLed;
	private Linear waterLevelBarGraph;
	private CoffeeMachine machine;
	private int ticksTimers;
	private PumpSate displayedPumpState;
	public CoffeeMachineGUI(CoffeeMachine machine) {
		this.machine = machine;
	}

	public void createAndShowUI() {
		final JFrame frame = new JFrame();
		JPanel contentPane = new JPanel(new BorderLayout());
		frame.setContentPane(contentPane);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// Left panel - water 
		JPanel waterPanel = createWaterPanel();
		contentPane.add(waterPanel, BorderLayout.WEST);

		// Right panel - temperature
		JPanel gaugePanel = createGaugesPanel();
		contentPane.add(gaugePanel, BorderLayout.EAST);

		//Buttons Panel - Bottom
		JPanel buttonsPanel = createButtonsPanel();
		contentPane.add(buttonsPanel, BorderLayout.SOUTH);

		//Coffee Image (Center)
		ImageIcon coffeeImage = createImageIcon("coffee.png", "Tasse à café");
		JLabel labelImage = new JLabel(coffeeImage, JLabel.CENTER);

		contentPane.add(labelImage, BorderLayout.CENTER);
		
		refreshUI();

		frame.setMinimumSize(new Dimension(850, 640));
		frame.setMaximumSize(new Dimension(1000, 640));
		frame.setSize(1000, 640);
		frame.setVisible(true);
	}

	private JPanel createButtonsPanel() {
		JPanel buttonsPanel = new JPanel();
		buttonsPanel.setLayout(new BoxLayout(buttonsPanel, BoxLayout.X_AXIS));
		buttonsPanel.add(Box.createHorizontalGlue());
		
		//One cup left button
		ImageIcon oneCupButtonIcon = createImageIcon("oneCup.png", "One cup");
		JButton oneCupButton = new JButton(oneCupButtonIcon);
		oneCupButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("One cup button");
				machine.oneCupButtonPressed();
			}
		});
		buttonsPanel.add(oneCupButton);
		buttonsPanel.add(Box.createHorizontalStrut(SPACER_SIZE));
		
		//Power center button
		ImageIcon powerIcon = createImageIcon("powerButton.png", "With great power comes great responsibility");
		JButton powerButton = new JButton(powerIcon);
		powerButton.setBorder(null);
		powerButton.setBorderPainted(false);
		powerButton.setFocusable(false);
		powerButton.setToolTipText("With great power comes great responsibility");
		powerButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("Power button");
				machine.powerButtonPressed();
			}
		});
		buttonsPanel.add(powerButton);
		buttonsPanel.add(Box.createHorizontalStrut(SPACER_SIZE));
		
		//Two cups right button
		ImageIcon twoCupsButtonIcon = createImageIcon("twoCups.png", "One cup");
		JButton twoCupsButton = new JButton(twoCupsButtonIcon);
		twoCupsButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("Two cups button");
				machine.twoCupsButtonPressed();
			}
		});
		buttonsPanel.add(twoCupsButton);
		
		buttonsPanel.add(Box.createHorizontalGlue());
		
		JPanel verticalSpacer = new JPanel();
		verticalSpacer.setLayout(new BoxLayout(verticalSpacer, BoxLayout.Y_AXIS));
		verticalSpacer.add(buttonsPanel);
		verticalSpacer.add(Box.createVerticalStrut(5));

		return verticalSpacer;
	}

	private JPanel createGaugesPanel() {
		JPanel gaugesPanel = new JPanel();
		gaugesPanel.setLayout(new BoxLayout(gaugesPanel, BoxLayout.Y_AXIS));
		
		gaugesPanel.add(Box.createVerticalGlue());
		gaugesPanel.add(Box.createVerticalStrut(SPACER_SIZE));
		
		temperatureGauge = new Radial();
		temperatureGauge.setTitle("Temperature");
		temperatureGauge.setUnitString("°C");
		temperatureGauge.setLcdUnitString("°C");
		temperatureGauge.setLcdUnitStringVisible(true);
		temperatureGauge.setLedVisible(false);
		temperatureGauge.setPreferredSize(new Dimension(GAUGE_SIZE, GAUGE_SIZE));
		gaugesPanel.add(temperatureGauge);
		
		gaugesPanel.add(Box.createVerticalStrut(SPACER_SIZE));
		
		pressureGauge = new Radial1Vertical();
		pressureGauge.setTitle("Pression pompe");
		pressureGauge.setUnitString("%");
		pressureGauge.setPreferredSize(new Dimension(GAUGE_SIZE, GAUGE_SIZE));
		pressureGauge.setLedVisible(false);
		pressureGauge.setLcdVisible(false);
		pressureGauge.setMaxNoOfMajorTicks(6);
		pressureGauge.setBackgroundColor(BackgroundColor.BEIGE);
		
		gaugesPanel.add(pressureGauge);
		
		gaugesPanel.add(Box.createVerticalStrut(SPACER_SIZE));
		
		heatingLed = new Led();
		heatingLed.setPreferredSize(new Dimension(LED_SIZE, LED_SIZE));
		heatingLed.setMinimumSize(new Dimension(LED_SIZE, LED_SIZE));
		heatingLed.setMaximumSize(new Dimension(LED_SIZE, LED_SIZE));
		
		gaugesPanel.add(heatingLed);
		gaugesPanel.add(Box.createVerticalGlue());
		
		return gaugesPanel;
	}

	private JPanel createWaterPanel() {
		JPanel waterPanel = new JPanel();
		waterPanel.setLayout(new BoxLayout(waterPanel, BoxLayout.Y_AXIS));

		JButton addWaterButton = new JButton("Ajouter de l'eau");
		addWaterButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				machine.addWater();
				
			}
		});
		addWaterButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		waterPanel.add(addWaterButton);
		waterLevelBarGraph = new Linear();
		waterLevelBarGraph.setTitle("Niveau d'eau");
		waterLevelBarGraph.setUnitString("%");
		waterLevelBarGraph.setValueColor(ColorDef.BLUE);
		waterLevelBarGraph.setLcdVisible(false);
		waterLevelBarGraph.setLedVisible(false);
		waterLevelBarGraph.setPreferredSize(new Dimension(150, 500));

		waterPanel.add(waterLevelBarGraph);
		return waterPanel;
	}

	/** Returns an ImageIcon, or null if the path was invalid. */
	private static ImageIcon createImageIcon(String path, String description) {
		path = "/Resources/Images/" + path;
		java.net.URL imgURL = CoffeeMachineGUI.class.getResource(path);
		if (imgURL != null) {
			return new ImageIcon(imgURL, description);
		} else {
			System.err.println("Couldn't find file: " + path);
			return null;
		}
	}

	@Override
	public void update(Observable o, Object arg) {
		refreshUI();
	}

	private void refreshUI() {
		if(machine.getWaterLevel() != waterLevelBarGraph.getValue()){
			waterLevelBarGraph.setValue(machine.getWaterLevel());
		}
		
		if(machine.getPumpState() != displayedPumpState ){
			double pressure = (machine.getPumpState() == PumpSate.OFF) ? 0 : 80;
			pressureGauge.setValueAnimated(pressure);
			displayedPumpState = machine.getPumpState();
		}

		temperatureGauge.setValue(machine.getWaterTemperature());
		heatingLed.setLedBlinking(false);
		switch(machine.getLedState()){
			case OFF:
				heatingLed.setLedOn(false);
				break;
				
			case ON:
				heatingLed.setLedOn(true);
				break;
				
			case BLINKING_FAST:
				ticksTimers = (ticksTimers + 1) % BLINK_PERIOD_FAST;
				if(ticksTimers == 0){
					heatingLed.setLedOn(!heatingLed.isLedOn());
				}
				break;
				
			case BLINKING_SLOW:
				ticksTimers = (ticksTimers + 1) % BLINK_PERIOD_SLOW;
				if(ticksTimers == 0){
					heatingLed.setLedOn(!heatingLed.isLedOn());
				}
				break;
				
		}
	}
}
