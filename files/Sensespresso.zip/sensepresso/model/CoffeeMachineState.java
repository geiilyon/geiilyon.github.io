package sensepresso.model;

public abstract class CoffeeMachineState {

	protected final CoffeeMachine coffeeMachine;

	public CoffeeMachineState(CoffeeMachine coffeeMachine) {
		this.coffeeMachine = coffeeMachine;
	}
	
	//Events
	//Power button defaults to turning off
	public void powerButtonPressed() {
		transitionToState(new CoffeeMachineOffState(coffeeMachine));
	}
	
	//Empty default implementations
	public void oneCupButtonPressed() {}

	public void twoCupsButtonPressed() {}

	public void temperatureDidChange() {}

	public void waterLevelDidChange() {}
	
	//State life cycle - empty default implementation
	protected void entry() {}
	
	protected void exit() {}
	
	//Transition
	protected void transitionToState(CoffeeMachineState nextState){
		CoffeeMachineState currentState = coffeeMachine.getCurrentState();
		if(currentState != nextState){
			currentState.exit();
			coffeeMachine.setCurrentState(nextState);
			nextState.entry();
		}
	}

}
