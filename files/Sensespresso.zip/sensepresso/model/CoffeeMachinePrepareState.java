package sensepresso.model;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Timer;

public class CoffeeMachinePrepareState extends CoffeeMachineState implements ActionListener {
	
	private Timer timer;

	public CoffeeMachinePrepareState(CoffeeMachine coffeeMachine) {
		super(coffeeMachine);
	}

	@Override
	public void powerButtonPressed() {
		transitionToState(new CoffeeMachineHeatingState(coffeeMachine));
	}

	@Override
	public void waterLevelDidChange() {
		//If there is no more water - taking evaporation into account 
		if(!coffeeMachine.isWaterLevelAboveThreshold()){
			transitionToState(new CoffeeMachineMissingWaterState(coffeeMachine));
		}
	}

	@Override
	protected void entry() {
		coffeeMachine.setLedState(LedState.BLINKING_SLOW);
		coffeeMachine.setHeaterState(HeaterState.KEEP_WARM);
		coffeeMachine.setPumpState(PumpSate.ON);
		int duration = (coffeeMachine.getNumberOfCups() == 1) ? 6000 : 12000 ;
		//Start a timer whose duration depends on the number of cups to prepare
		timer = new Timer(duration , this);
		timer.setRepeats(false);
		timer.start();
	}

	@Override
	protected void exit() {
		timer.stop();
		coffeeMachine.setPumpState(PumpSate.OFF);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		transitionToState(new CoffeeMachineHeatingState(coffeeMachine));
		
	}
	
	

}
