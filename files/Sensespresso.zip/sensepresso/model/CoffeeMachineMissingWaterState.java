package sensepresso.model;

public class CoffeeMachineMissingWaterState extends CoffeeMachineState {

	public CoffeeMachineMissingWaterState(CoffeeMachine coffeeMachine) {
		super(coffeeMachine);
	}
	
	@Override
	public void waterLevelDidChange() {
		if(coffeeMachine.isWaterLevelAboveThreshold()){
			transitionToState(new CoffeeMachineHeatingState(coffeeMachine));
		}
	}

	@Override
	protected void entry() {
		coffeeMachine.setLedState(LedState.BLINKING_FAST);
		coffeeMachine.setHeaterState(HeaterState.OFF);
	}


}
