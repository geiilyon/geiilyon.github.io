package sensepresso.model;

public class CoffeeMachineHeatingState extends CoffeeMachineState {

	public CoffeeMachineHeatingState(CoffeeMachine coffeeMachine) {
		super(coffeeMachine);
	}

	@Override
	protected void entry() {
		coffeeMachine.setHeaterState(HeaterState.HEAT);
		coffeeMachine.setLedState(LedState.BLINKING_SLOW);
	}

	@Override
	public void temperatureDidChange() {
		if(coffeeMachine.isTemperatureAboveThreshold()){
			transitionToState(new CoffeeMachineReadyState(coffeeMachine));
		}
	}

	@Override
	public void waterLevelDidChange() {
		//If there is no more water - taking evaporation into account 
		if(!coffeeMachine.isWaterLevelAboveThreshold()){
			transitionToState(new CoffeeMachineMissingWaterState(coffeeMachine));
		}
	}
}
