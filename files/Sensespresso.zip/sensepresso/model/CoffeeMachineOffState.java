package sensepresso.model;

public class CoffeeMachineOffState extends CoffeeMachineState {

	public CoffeeMachineOffState(CoffeeMachine coffeeMachine) {
		super(coffeeMachine);
	}

	@Override
	public void powerButtonPressed() {
		if(coffeeMachine.isWaterLevelAboveThreshold()){
			transitionToState(new CoffeeMachineHeatingState(coffeeMachine));
		}else{
			transitionToState(new CoffeeMachineMissingWaterState(coffeeMachine));
		}
	}

	@Override
	protected void entry() {
		coffeeMachine.setLedState(LedState.OFF);
		coffeeMachine.setHeaterState(HeaterState.OFF);
	}	
	
}
