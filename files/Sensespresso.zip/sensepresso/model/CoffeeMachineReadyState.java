package sensepresso.model;

public class CoffeeMachineReadyState extends CoffeeMachineState {

	public CoffeeMachineReadyState(CoffeeMachine coffeeMachine) {
		super(coffeeMachine);
	}

	@Override
	protected void entry() {
		coffeeMachine.setLedState(LedState.ON);
		coffeeMachine.setHeaterState(HeaterState.KEEP_WARM);
	}
	
	@Override
	public void waterLevelDidChange() {
		//If there is no more water - someone removes the tank 
		if(!coffeeMachine.isWaterLevelAboveThreshold()){
			transitionToState(new CoffeeMachineMissingWaterState(coffeeMachine));
		}
	}

	@Override
	public void temperatureDidChange() {
		if(!coffeeMachine.isTemperatureAboveThreshold()) {
			transitionToState(new CoffeeMachineHeatingState(coffeeMachine));
		}
	}

	@Override
	public void oneCupButtonPressed() {
		prepareNbCups(1);
	}

	@Override
	public void twoCupsButtonPressed() {
		prepareNbCups(2);
	}

	private void prepareNbCups(int nbCups) {
		coffeeMachine.setNumberOfCups(nbCups);
		transitionToState(new CoffeeMachinePrepareState(coffeeMachine));
	}
}
