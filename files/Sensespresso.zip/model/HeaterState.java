package model;

public enum HeaterState {
	OFF,
	HEAT,
	KEEP_WARM
	
}
