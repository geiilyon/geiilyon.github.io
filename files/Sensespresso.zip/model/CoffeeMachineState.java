package model;

public abstract class CoffeeMachineState {

	protected final CoffeeMachine coffeeMachine;

	public CoffeeMachineState(CoffeeMachine coffeeMachine) {
		this.coffeeMachine = coffeeMachine;
	}
	
	//Events
	public void powerButtonPressed() {}
	
	//Empty default implementations
	public void oneCupButtonPressed() {}

	public void twoCupsButtonPressed() {}

	public void temperatureDidChange() {}

	public void waterLevelDidChange() {}
	
	//State life cycle - empty default implementation
	protected void entry() {}
	
	protected void exit() {}
	
	//Transition
	protected void transitionToState(CoffeeMachineState nextState){
	}

}
