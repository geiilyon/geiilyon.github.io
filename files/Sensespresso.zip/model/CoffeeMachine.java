package model;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Observable;

import javax.swing.Timer;

public class CoffeeMachine extends Observable implements ActionListener {

	private double waterLevel = 0;
	private double waterTemperature = 10;
	private HeaterState heaterState = HeaterState.OFF;
	private LedState ledState = LedState.OFF;
	private PumpSate pumpState;
	private int numberOfCups;

	private CoffeeMachineState currentState;

	public static final int TEMP_THRESHOLD = 80;
	public static final int TEMP_EAU_FROIDE = 10;

	public static final int WATER_THRESHOLD = 10;

	// Physics simulation
	private Timer physicsSimulationTimer;
	private double waterToAdd = 0;
	private static final double WATER_INCREMENTS = 1;
	private static final int TIMER_PERIOD = 100;
	public static final double TEMP_POSITIVE_GRADIENT = 0.4; // heater
	public static final double TEMP_NEGATIVE_GRADIENT = 0.2; // natural cooling

	public CoffeeMachine() {
		super();
		currentState = new CoffeeMachineOffState(this);
		physicsSimulationTimer = new Timer(TIMER_PERIOD, this);
		physicsSimulationTimer.setRepeats(true);
		physicsSimulationTimer.start();
	}

	public void addWater() {
		if (waterLevel < 100){
			//Fill until next multiple of 20 graduation
			waterToAdd = (20 - (waterLevel % 20));
		}
	}

	public double getWaterLevel() {
		return waterLevel;
	}

	public boolean isWaterLevelAboveThreshold() {
		return waterLevel >= WATER_THRESHOLD;
	}

	public double getWaterTemperature() {
		return waterTemperature;
	}

	public boolean isTemperatureAboveThreshold() {
		return waterTemperature >= TEMP_THRESHOLD;
	}

	public LedState getLedState() {
		return ledState;
	}

	void setLedState(LedState ledState) {
		this.ledState = ledState;
		modelChanged();
	}

	CoffeeMachineState getCurrentState() {
		return currentState;
	}

	void setCurrentState(CoffeeMachineState currentState) {
		this.currentState = currentState;
	}

	public HeaterState getHeaterState() {
		return heaterState;
	}

	void setHeaterState(HeaterState heaterState) {
		this.heaterState = heaterState;
	}

	public PumpSate getPumpState() {
		return pumpState;
	}

	public void setPumpState(PumpSate pumpState) {
		this.pumpState = pumpState;

	}

	public void setNumberOfCups(int numberOfCups) {
		this.numberOfCups = numberOfCups;
	}

	public int getNumberOfCups() {
		return numberOfCups;
	}

	public void powerButtonPressed() {
		currentState.powerButtonPressed();
	}

	public void oneCupButtonPressed() {
		currentState.oneCupButtonPressed();
	}

	public void twoCupsButtonPressed() {
		currentState.twoCupsButtonPressed();
	}

	/* Simulation physique - méthode appelée par le timer */
	@Override
	public void actionPerformed(ActionEvent e) {
		temperatureSimulation();
		waterPouringSimulation();
		pumpSimulation();
		modelChanged();

	}

	private void pumpSimulation() {
		if(pumpState == PumpSate.ON){
			waterLevel -= 0.3;
			currentState.waterLevelDidChange();
		}
	}

	private void waterPouringSimulation() {
		if (waterToAdd > 0) {
			// Update temperature
			waterTemperature = (waterTemperature * waterLevel + TEMP_EAU_FROIDE * WATER_INCREMENTS) / (waterLevel + WATER_INCREMENTS);
			waterLevel += WATER_INCREMENTS;
			waterToAdd -= WATER_INCREMENTS;
			currentState.waterLevelDidChange();
		}

	}

	private void temperatureSimulation() {
		switch (heaterState) {
		case OFF:
			waterTemperature -= TEMP_NEGATIVE_GRADIENT;
			if (waterTemperature < TEMP_EAU_FROIDE) {
				waterTemperature = TEMP_EAU_FROIDE;
			}
			break;

		case HEAT:
			waterTemperature += TEMP_POSITIVE_GRADIENT;
			break;

		case KEEP_WARM:
			break;

		}

		currentState.temperatureDidChange();
	}

	private void modelChanged() {
		setChanged();
		notifyObservers();
	}

}
