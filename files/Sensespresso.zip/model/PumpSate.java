package model;

public enum PumpSate {
	ON,
	OFF

}
